#include <Arduino.h>
#include <Ps3Controller.h>
#include <qei.hpp>

#define PI  3.14159265
#define PPR 1024
#define rawToDeg 131.068
#define RobotMaxSpeed 4.0f // m/s
#define speed_limit 6.0f // m/s
#define control_frequency 500 // us
#define Max_Rotate_speed 30 // deg/s
#define centorWheelLength 141.421356 // mm
#define MaxDuty 255

// MAC add -----> 3C:61:05:30:6A:4E

//ゲインピン
const int adjust_gain_pin1 = 36;
const int adjust_gain_pin2 = 39;
//マイコンのピン設定（どのピンに何を接続しているか）
const int motor1_dir = 25;
const int motor2_dir = 14;
const int motor3_dir = 26;
const int motor4_dir = 32;

const int motor1_pwm_pin = 27;
const int motor2_pwm_pin = 13;
const int motor3_pwm_pin = 12;
const int motor4_pwm_pin = 33;

int motor1_pwm = 0;
int motor2_pwm = 0;
int motor3_pwm = 0;
int motor4_pwm = 0;

int v1 = 0;
int v2 = 0;
int v3 = 0;
int v4 = 0;

//ゲイン
int kp = 0;
int kd = 0;
//目標値
int valx = 0;//速度指令にする？
int valy = 0;
int valt = 0;
//Ps3から送られてきたデータ
int joy_right_x = 0;
int joy_right_y = 0;


void setup(){
  Serial.begin(115200);
  Ps3.begin("3C:61:05:30:6A:4E");
  qei_setup_x4(PCNT_UNIT_0, GPIO_NUM_18, GPIO_NUM_5);//エンコーダの設定
  qei_setup_x4(PCNT_UNIT_1, GPIO_NUM_18, GPIO_NUM_5);
  qei_setup_x4(PCNT_UNIT_2, GPIO_NUM_18, GPIO_NUM_5);

  pinMode(motor1_dir, OUTPUT);
  pinMode(motor2_dir, OUTPUT);
  pinMode(motor3_dir, OUTPUT);
  pinMode(motor4_dir, OUTPUT);
  ledcSetup(1, 20000, 8);
  ledcSetup(2, 20000, 8);
  ledcSetup(3, 20000, 8);
  ledcSetup(4, 20000, 8);
  ledcAttachPin(motor1_pwm_pin, 1);
  ledcAttachPin(motor2_pwm_pin, 2);
  ledcAttachPin(motor3_pwm_pin, 3);
  ledcAttachPin(motor4_pwm_pin, 4);


  pinMode(adjust_gain_pin1, INPUT);
  pinMode(adjust_gain_pin2, INPUT);

}

void loop()
{
  if (Ps3.isConnected()){
    kp = analogRead(adjust_gain_pin1);
    kd = analogRead(adjust_gain_pin2);
    joy_right_x = Ps3.data.analog.stick.rx;
    joy_right_y = -Ps3.data.analog.stick.ry;

    //Serial.print("right_x --- ");
    //Serial.print(joy_right_x);
    //Serial.print("   right_y ---  ");
    //Serial.println(joy_right_y);

    v1 = -joy_right_x+joy_right_y;
    v2 = joy_right_x+joy_right_y;
    v3 = -joy_right_x+joy_right_y;
    v4 = joy_right_x+joy_right_y;

    

    motor1_pwm = abs(v1);
    motor2_pwm = abs(v2);
    motor3_pwm = abs(v3);
    motor4_pwm = abs(v4);

    if (abs(motor1_pwm) > MaxDuty){
      motor1_pwm = MaxDuty;
      }
    if (abs(motor2_pwm) > MaxDuty){
      motor2_pwm = MaxDuty;
      }
    if (abs(motor3_pwm) > MaxDuty){
      motor3_pwm = MaxDuty;
      }
    if (abs(motor4_pwm) > MaxDuty){
      motor4_pwm = MaxDuty;
      }
    



    if(v1 > 0){
      ledcWrite(1, motor1_pwm);
      digitalWrite(motor1_dir, HIGH);
    }else{
      ledcWrite(1, motor1_pwm);
      digitalWrite(motor1_dir, LOW);
    }

    if(v2 > 0){
      ledcWrite(2, motor2_pwm);
      digitalWrite(motor2_dir, LOW);
    }else{
      ledcWrite(2, motor2_pwm);
      digitalWrite(motor2_dir, HIGH);
    }

    if(v3 > 0){
      ledcWrite(3, motor3_pwm);
      digitalWrite(motor3_dir, HIGH);
    }else{
      ledcWrite(3, motor3_pwm);
      digitalWrite(motor3_dir, LOW);
    }

    if(v4 > 0){
      ledcWrite(4, motor4_pwm);
      digitalWrite(motor4_dir, LOW);
    }else{
      ledcWrite(4, motor4_pwm);
      digitalWrite(motor4_dir, HIGH);
    }
    
    


  }
}